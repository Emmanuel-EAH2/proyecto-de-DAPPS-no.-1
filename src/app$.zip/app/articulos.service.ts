import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ArticulosService {
  url='http://localhost/conexion.php';
  constructor(private http: HttpClient) { }
  
  recuperarTodos(){
    return this.http.get(`${this.url}conexion.php`);
  }
  
  alta(articulo){
    return this.http.post(`${this.url}alta.php`, JSON.stringify(articulo));
  }
}
